package weekTen.abstractClasses.interfaces;

public interface Interactable
{
    void User();
    void Customer();
    void Staff();


    }

