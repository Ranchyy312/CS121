package weekEleven.sortingActivity;

import java.util.Scanner;

public class Sorting {
    public int[] getArray() {

        Scanner keyboard = new Scanner(System.in);

        System.out.println("Enter the first number: ");
        int num1 = keyboard.nextInt();
        System.out.println("Enter the second number: ");
        int num2 = keyboard.nextInt();
        System.out.println("Enter the third number: ");
        int num3 = keyboard.nextInt();
        System.out.println("Enter the fourth number: ");
        int num4 = keyboard.nextInt();
        System.out.println("Enter the fifth number: ");
        int num5 = keyboard.nextInt();

        int unsortedInput[] = {num1, num2, num3, num4, num5};
        return unsortedInput;
    }

    public int[] sortArray(int[] unsortedArray) {
        int temp;

        for(int i = 0; i<unsortedArray.length - 1; i++){
            for(int index = 0; index < unsortedArray.length - i - 1; index++ ){
                if(unsortedArray[index] > unsortedArray[index+1]){
                    temp = unsortedArray[index];
                    unsortedArray[index]=unsortedArray[index+1];
                    unsortedArray[index+1]=temp;
                }
            }
        }

        return unsortedArray;
    }
}

