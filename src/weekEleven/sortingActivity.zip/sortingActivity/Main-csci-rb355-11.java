package weekEleven.sortingActivity;

import weekEleven.sortingActivity.Sorting.*;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        Sorting sorting = new Sorting();
        int unsortedArray[] = sorting.getArray();
        System.out.println("Sorting....");
        int sortedArray[] = sorting.sortArray(unsortedArray);
        System.out.println("This is your sorted array:");
        System.out.print(Arrays.toString(sortedArray));
    }
}
