package weekSix.classActivity;
public class SandwichClass {
    String bread, cheese, topping, meats;
    int numSandwich;

    SandwichClass(String bread, String cheese, String topping, String meats, int numSandwich) {
        this.bread = bread;
        this.cheese = cheese;
        this.topping = topping;
        this.meats = meats;
        this.numSandwich = numSandwich;
    }
    public void displayInfo(){
        System.out.printf("Your sandwich has %s bread and %s cheese, with %s as a topping and %s as a meat. You made %d sandwiches.", bread,cheese,topping,meats,numSandwich);
    }
}